
import { Component } from '@angular/core';




@Component({

  selector: 'app-userviewpolicy',

  templateUrl: './userviewpolicy.component.html',

  styleUrls: ['./userviewpolicy.component.css']

})

export class UserviewpolicyComponent {




}





