﻿using Microsoft.AspNetCore.Http;

namespace LifeInsurance.Models
{
    public class FileUploadModel
    {
        public IFormFile File { get; set; }
    }
}
