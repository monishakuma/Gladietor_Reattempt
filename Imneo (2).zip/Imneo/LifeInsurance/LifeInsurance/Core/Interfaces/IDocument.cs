﻿using LifeInsurance.Models;
using Microsoft.AspNetCore.Mvc;

namespace LifeInsurance.Core.Interfaces
{
    public interface IDocument
    {
       Task<IActionResult> Upload([FromForm] FileUploadModel model);
    }
}
