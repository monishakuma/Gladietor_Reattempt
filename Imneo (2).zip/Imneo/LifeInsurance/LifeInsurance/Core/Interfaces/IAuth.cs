﻿using LifeInsurance.Models;
using Microsoft.AspNetCore.Mvc;

namespace LifeInsurance.Core.Interfaces
{
    public interface IAuth
    {
        Task<ResponseModel> RegisterUser(UserModel userModel);
        ResponseModel GenerateToken(LoginModel loginModel);

    }
}
